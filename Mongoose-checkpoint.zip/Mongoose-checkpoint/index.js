// Import required libraries
const mongoose = require('mongoose');
const Person = require("./person");


// Set up mongoose connection
mongoose.connect(process.env.MONGO_URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true
});

// Create and Save a Record
const newPerson = new Person({
  name: 'John Doe',
  age: 30,
  favoriteFoods: ['Pizza', 'Burger']
});

newPerson.save(function(err, data) {
  if (err) {
    console.error(err);
  } else {
    console.log('New person saved:', data);
  }
});

// Create Many Records
const arrayOfPeople = [
  { name: 'Alice', age: 25, favoriteFoods: ['Sushi', 'Pasta'] },
  { name: 'Bob', age: 28, favoriteFoods: ['Burger', 'Tacos'] }
];

Person.create(arrayOfPeople, function(err, people) {
  if (err) {
    console.error(err);
  } else {
    console.log('People created:', people);
  }
});

// Use model.find() to Search Your Database
Person.find({ name: 'John Doe' }, function(err, foundPeople) {
  if (err) {
    console.error(err);
  } else {
    console.log('People with name "John Doe":', foundPeople);
  }
});

// Use model.findOne() to Return a Single Matching Document
Person.findOne({ favoriteFoods: 'Pizza' }, function(err, person) {
  if (err) {
    console.error(err);
  } else {
    console.log('Person who likes Pizza:', person);
  }
});

// Use model.findById() to Search Your Database By _id
const personId = 'your_person_id_here';
Person.findById(personId, function(err, person) {
  if (err) {
    console.error(err);
  } else {
    console.log('Person by ID:', person);
  }
});

// Perform Classic Updates
const personIdToUpdate = 'your_person_id_here';
Person.findById(personIdToUpdate, function(err, person) {
  if (err) {
    console.error(err);
  } else {
    person.favoriteFoods.push('Hamburger');
    person.save(function(err, updatedPerson) {
      if (err) {
        console.error(err);
      } else {
        console.log('Updated person:', updatedPerson);
      }
    });
  }
});

// Perform New Updates on a Document Using model.findOneAndUpdate()
const personNameToUpdate = 'John Doe';
Person.findOneAndUpdate(
  { name: personNameToUpdate },
  { age: 20 },
  { new: true },
  function(err, updatedPerson) {
    if (err) {
      console.error(err);
    } else {
      console.log('Updated person by name:', updatedPerson);
    }
  }
);

// Delete One Document Using model.findByIdAndRemove
const personIdToDelete = 'your_person_id_here';
Person.findByIdAndRemove(personIdToDelete, function(err, removedPerson) {
  if (err) {
    console.error(err);
  } else {
    console.log('Removed person:', removedPerson);
  }
});

// MongoDB and Mongoose - Delete Many Documents with model.remove()
const nameToDelete = 'Mary';
Person.remove({ name: nameToDelete }, function(err, result) {
  if (err) {
    console.error(err);
  } else {
    console.log('Deleted', result.n, 'people named', nameToDelete);
  }
});

// Chain Search Query Helpers
Person.find({ favoriteFoods: 'Burritos' })
  .sort('name')
  .limit(2)
  .select('-age')
  .exec(function(err, data) {
    if (err) {
      console.error(err);
    } else {
      console.log('People who like Burritos:', data);
    }
  });
