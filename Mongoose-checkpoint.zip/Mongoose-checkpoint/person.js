const mongoose = require("mongoose");

// Create a Person Schema
const personSchema = new mongoose.Schema({
    name: { type: String, required: true },
    age: Number,
    favoriteFoods: [String]
  });
  
  // Create a Person Model
  const Person = mongoose.model('Person', personSchema);